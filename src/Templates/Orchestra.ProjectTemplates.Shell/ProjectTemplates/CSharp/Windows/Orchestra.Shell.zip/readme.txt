Orchestra shell project template readme
=======================================

Congratulations with creating a new Orchestra shell project:

$safeprojectname$

To get this project up and running, perform the following actions:

1) Right-click on the project => Manage NuGet packages...
2) Search for Orchestra.Shell
3) Install the NuGet package
4) Build and run the application


For more information and support, visit https://github.com/orcomp/orchestra
Orchestra module project template readme
========================================

Congratulations with creating a new Orchestra module project:

$safeprojectname$

To get this project up and running, perform the following actions:

1) Right-click on the project => Manage NuGet packages...
2) Search for Orchestra.Library
3) Install the NuGet package
4) Build and run the application


Note that because modules are dynamically loaded, you must first build this module before running
the shell. When only running the shell, the module will not be built by Visual Studio and thus
will not be found by the Orchestra shell.

For more information and support, visit https://github.com/orcomp/orchestra
﻿namespace $safeprojectname$
{
	using Catel.MVVM;
	using Catel.MVVM.Services;
	using Orchestra.Models;
	using Orchestra.Modules;
	using Orchestra.Services;

    /// <summary>
    /// The module.
    /// </summary>
    public class MyModule : Orchestra.Modules.ModuleBase
    {
        private readonly IOrchestraService _orchestraService;
        private readonly IMessageService _messageService;	
	
        /// <summary>
        /// Initializes the module.
        /// </summary>
        /// <param name="orchestraService">The orchestra service.</param>
        /// <param name="messageService">The message service.</param>
        public MyModule(IOrchestraService orchestraService, IMessageService messageService)
            : base("MyModule")
        {
            _orchestraService = orchestraService;
            _messageService = messageService;
        }

        /// <summary>
        /// Called when the module is initialized.
        /// </summary>
        protected override void OnInitialized()
        {
			// TODO: Register ribbon items
            //var openRibbonItem = new RibbonItem(ModuleName, ModuleName, "Action name", new Command(() =>
            //    {
            //        // Action to invoke
            //    }));
            //_orchestraService.AddRibbonItem(openRibbonItem);
			
			// TODO: Handle additional initialization code
			
			_messageService.ShowInformation(string.Format("Module '{0}' has been initialized, welcome to this module!", ModuleName));
        }
    }
}